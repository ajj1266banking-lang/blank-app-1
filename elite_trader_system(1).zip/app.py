
# ================= ELITE TRADER SYSTEM (STREAMLIT SAFE) =================
import streamlit as st
import pandas as pd
import sqlite3
import uuid
import hashlib
import matplotlib.pyplot as plt
from datetime import date
from pathlib import Path

DB_PATH = Path("trades.db")
UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(exist_ok=True)

MAX_DRAWDOWN_WARN = -500
MAX_DRAWDOWN_STOP = -1000
MAX_TRADES_PER_DAY = 3

st.set_page_config("Elite Trader System", layout="wide")

def get_conn():
    return sqlite3.connect(DB_PATH, check_same_thread=False)

def init_db():
    with get_conn() as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS users (username TEXT PRIMARY KEY, password TEXT)")
        conn.execute("""CREATE TABLE IF NOT EXISTS trades (
            id TEXT PRIMARY KEY,
            trade_date TEXT,
            symbol TEXT,
            strategy TEXT,
            size INTEGER,
            max_loss REAL,
            pnl REAL,
            r_multiple REAL,
            mistakes TEXT,
            review TEXT,
            user TEXT,
            session TEXT,
            emotion TEXT,
            quality INTEGER
        )""")

init_db()

def hash_pw(pw):
    return hashlib.sha256(("elite_salt_" + pw).encode()).hexdigest()

if "user" not in st.session_state:
    st.session_state.user = None

if not st.session_state.user:
    st.title("Login")
    u = st.text_input("Username")
    p = st.text_input("Password", type="password")
    if st.button("Login / Register"):
        with get_conn() as conn:
            conn.execute("INSERT OR IGNORE INTO users VALUES (?,?)", (u, hash_pw(p)))
            pw = conn.execute("SELECT password FROM users WHERE username=?", (u,)).fetchone()
        if pw and pw[0] == hash_pw(p):
            st.session_state.user = u
            st.rerun()
        else:
            st.error("Invalid credentials")
    st.stop()

df = pd.read_sql("SELECT * FROM trades WHERE user=?", get_conn(), params=(st.session_state.user,))
if not df.empty:
    df["trade_date"] = pd.to_datetime(df["trade_date"])

risk_state = "GREEN"
if not df.empty:
    equity = df.sort_values("trade_date").pnl.cumsum()
    drawdown = equity - equity.cummax()
    max_dd = drawdown.min()
    if max_dd <= MAX_DRAWDOWN_STOP:
        risk_state = "RED"
    elif max_dd <= MAX_DRAWDOWN_WARN:
        risk_state = "YELLOW"

with st.sidebar:
    st.header(f"Trader: {st.session_state.user}")
    st.metric("Risk State", risk_state)
    page = st.radio("Navigate", ["Dashboard", "Add Trade", "Analytics", "All Trades"])
    if st.button("Logout"):
        st.session_state.user = None
        st.rerun()

if page == "Dashboard":
    st.header("Performance Overview")
    if df.empty:
        st.info("No trades yet")
    else:
        st.line_chart(df.sort_values("trade_date").set_index("trade_date")["pnl"].cumsum())

elif page == "Add Trade":
    if risk_state == "RED":
        st.error("Trading disabled due to drawdown")
        st.stop()
    with st.form("trade_form"):
        d = st.date_input("Date", value=date.today())
        s = st.text_input("Symbol").upper()
        pnl = st.number_input("P/L", step=1.0)
        risk = st.number_input("Risk ($)", value=100.0)
        session = st.selectbox("Session", ["Open", "Midday", "Close"])
        emotion = st.selectbox("Emotion", ["Calm", "FOMO", "Fear", "Revenge"])
        review = st.text_area("Post-Trade Review")
        if st.form_submit_button("Save"):
            r_mult = pnl / risk if risk else 0
            with get_conn() as conn:
                conn.execute("""INSERT INTO trades (
                    id, trade_date, symbol, strategy, size, max_loss, pnl, r_multiple,
                    mistakes, review, user, session, emotion, quality
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (
                    str(uuid.uuid4()), d.isoformat(), s, "Manual", 1, risk,
                    pnl, r_mult, "", review, st.session_state.user,
                    session, emotion, 3
                ))
            st.success("Trade saved")
            st.rerun()

elif page == "Analytics" and not df.empty:
    fig, ax = plt.subplots()
    df.groupby(df.trade_date.dt.day_name()).pnl.sum().plot(kind="bar", ax=ax)
    st.pyplot(fig)

elif page == "All Trades":
    st.dataframe(df.sort_values("trade_date", ascending=False))

